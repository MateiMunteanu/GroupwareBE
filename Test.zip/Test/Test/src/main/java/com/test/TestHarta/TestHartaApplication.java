package com.test.TestHarta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestHartaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestHartaApplication.class, args);
	}

}
