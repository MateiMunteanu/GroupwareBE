package com.test.TestHarta.User;

public enum Role {

    USER,
    ADMIN,
    EVENTOWNER
}
