package com.test.TestHarta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestHartaApplicationTests {

	@Test
	void contextLoads() {
	}

}
